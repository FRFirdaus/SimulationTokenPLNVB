﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.tmrLUAR = New System.Windows.Forms.Timer(Me.components)
        Me.tmrRUMAH = New System.Windows.Forms.Timer(Me.components)
        Me.tmrAC = New System.Windows.Forms.Timer(Me.components)
        Me.tmrTV = New System.Windows.Forms.Timer(Me.components)
        Me.tmrMASUKINDO = New System.Windows.Forms.Timer(Me.components)
        Me.tmrKELUARINDO = New System.Windows.Forms.Timer(Me.components)
        Me.tmrmbakindo = New System.Windows.Forms.Timer(Me.components)
        Me.grpISI = New System.Windows.Forms.GroupBox()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.txtMETERAN = New System.Windows.Forms.TextBox()
        Me.PictureBox12 = New System.Windows.Forms.PictureBox()
        Me.tmrISIIN = New System.Windows.Forms.Timer(Me.components)
        Me.tmrISIOUT = New System.Windows.Forms.Timer(Me.components)
        Me.tmrTONE = New System.Windows.Forms.Timer(Me.components)
        Me.grpTOKEN = New System.Windows.Forms.GroupBox()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.txtKODE = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cmbSALDO = New System.Windows.Forms.ComboBox()
        Me.lblnotoken = New System.Windows.Forms.Label()
        Me.lblWELCOME = New System.Windows.Forms.Label()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.btnCLOSEINDO = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblTOKEN = New System.Windows.Forms.Label()
        Me.txtNOMOR = New System.Windows.Forms.TextBox()
        Me.grpLUAR = New System.Windows.Forms.GroupBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.grpRUMAH = New System.Windows.Forms.GroupBox()
        Me.lblmonster = New System.Windows.Forms.Label()
        Me.pctM3 = New System.Windows.Forms.PictureBox()
        Me.pctM2 = New System.Windows.Forms.PictureBox()
        Me.pctM1 = New System.Windows.Forms.PictureBox()
        Me.btnSHOW = New System.Windows.Forms.Button()
        Me.grpPEMAKAIAN = New System.Windows.Forms.GroupBox()
        Me.lblGRAFIK = New System.Windows.Forms.Label()
        Me.LABELG3 = New System.Windows.Forms.Label()
        Me.LABELG2 = New System.Windows.Forms.Label()
        Me.LABELG1 = New System.Windows.Forms.Label()
        Me.dotYELLOW = New System.Windows.Forms.PictureBox()
        Me.dotRED = New System.Windows.Forms.PictureBox()
        Me.dotGold = New System.Windows.Forms.PictureBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.btngotv = New System.Windows.Forms.Button()
        Me.btngorad = New System.Windows.Forms.Button()
        Me.btngoac = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblpersentv = New System.Windows.Forms.Label()
        Me.lblANGKAUTV = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnSTAT = New System.Windows.Forms.Button()
        Me.lblpersenrad = New System.Windows.Forms.Label()
        Me.lblUAC = New System.Windows.Forms.Label()
        Me.lblpersenac = New System.Windows.Forms.Label()
        Me.lblURAD = New System.Windows.Forms.Label()
        Me.lblANGKAUAC = New System.Windows.Forms.Label()
        Me.lblANGKAURAD = New System.Windows.Forms.Label()
        Me.pctGSUARA = New System.Windows.Forms.PictureBox()
        Me.pctTONE1 = New System.Windows.Forms.PictureBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblISISALDO = New System.Windows.Forms.Label()
        Me.lblKODE = New System.Windows.Forms.Label()
        Me.pctARUSAC = New System.Windows.Forms.PictureBox()
        Me.pctRADI = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.pctTV = New System.Windows.Forms.PictureBox()
        Me.pctmeja = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.deskripsi = New System.Windows.Forms.ToolTip(Me.components)
        Me.led2 = New System.Windows.Forms.Timer(Me.components)
        Me.led3 = New System.Windows.Forms.Timer(Me.components)
        Me.led1 = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CreatorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProfileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SourceCodeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TimerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AnimasiRadioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AnimasiTVToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AnimasiKeluarRumahToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AnimasiMasukAlfamartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AnimasiTextSelamatDatangToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AnimasiPengisianTokenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AnimasiGrafikPemakaianToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ButtonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PictureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManualBookToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tmrGRAFIK = New System.Windows.Forms.Timer(Me.components)
        Me.grpISI.SuspendLayout()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpTOKEN.SuspendLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpLUAR.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpRUMAH.SuspendLayout()
        CType(Me.pctM3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctM2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctM1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpPEMAKAIAN.SuspendLayout()
        CType(Me.dotYELLOW, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dotRED, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dotGold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctGSUARA, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctTONE1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctARUSAC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctRADI, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctTV, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctmeja, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'tmrLUAR
        '
        Me.tmrLUAR.Interval = 10
        '
        'tmrRUMAH
        '
        Me.tmrRUMAH.Interval = 10
        '
        'tmrAC
        '
        Me.tmrAC.Interval = 10
        '
        'tmrTV
        '
        '
        'tmrMASUKINDO
        '
        Me.tmrMASUKINDO.Interval = 10
        '
        'tmrKELUARINDO
        '
        '
        'tmrmbakindo
        '
        '
        'grpISI
        '
        Me.grpISI.BackColor = System.Drawing.Color.Gold
        Me.grpISI.Controls.Add(Me.Button16)
        Me.grpISI.Controls.Add(Me.Button17)
        Me.grpISI.Controls.Add(Me.Button18)
        Me.grpISI.Controls.Add(Me.Button19)
        Me.grpISI.Controls.Add(Me.Button20)
        Me.grpISI.Controls.Add(Me.Button21)
        Me.grpISI.Controls.Add(Me.Button22)
        Me.grpISI.Controls.Add(Me.Button23)
        Me.grpISI.Controls.Add(Me.Button24)
        Me.grpISI.Controls.Add(Me.Button25)
        Me.grpISI.Controls.Add(Me.Button26)
        Me.grpISI.Controls.Add(Me.Button27)
        Me.grpISI.Controls.Add(Me.Button28)
        Me.grpISI.Controls.Add(Me.txtMETERAN)
        Me.grpISI.Controls.Add(Me.PictureBox12)
        Me.grpISI.Location = New System.Drawing.Point(1114, 30)
        Me.grpISI.Name = "grpISI"
        Me.grpISI.Size = New System.Drawing.Size(276, 694)
        Me.grpISI.TabIndex = 27
        Me.grpISI.TabStop = False
        Me.grpISI.Text = "Isi Token"
        '
        'Button16
        '
        Me.Button16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button16.Location = New System.Drawing.Point(193, 615)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(60, 40)
        Me.Button16.TabIndex = 26
        Me.Button16.Text = "Close"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button17.Location = New System.Drawing.Point(193, 546)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(60, 40)
        Me.Button17.TabIndex = 25
        Me.Button17.Text = "ok"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button18.Location = New System.Drawing.Point(109, 546)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(60, 40)
        Me.Button18.TabIndex = 24
        Me.Button18.Text = "0"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Button19
        '
        Me.Button19.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button19.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button19.Location = New System.Drawing.Point(25, 546)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(60, 40)
        Me.Button19.TabIndex = 23
        Me.Button19.Text = "<"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button20.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button20.Location = New System.Drawing.Point(193, 477)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(60, 40)
        Me.Button20.TabIndex = 22
        Me.Button20.Text = "9"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button21.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button21.Location = New System.Drawing.Point(109, 477)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(60, 40)
        Me.Button21.TabIndex = 21
        Me.Button21.Text = "8"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button22.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button22.Location = New System.Drawing.Point(25, 477)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(60, 40)
        Me.Button22.TabIndex = 20
        Me.Button22.Text = "7"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button23.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button23.Location = New System.Drawing.Point(193, 404)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(60, 40)
        Me.Button23.TabIndex = 19
        Me.Button23.Text = "6"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Button24
        '
        Me.Button24.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button24.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button24.Location = New System.Drawing.Point(25, 404)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(60, 40)
        Me.Button24.TabIndex = 18
        Me.Button24.Text = "4"
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Button25
        '
        Me.Button25.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button25.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button25.Location = New System.Drawing.Point(109, 404)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(60, 40)
        Me.Button25.TabIndex = 17
        Me.Button25.Text = "5"
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Button26
        '
        Me.Button26.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button26.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button26.Location = New System.Drawing.Point(193, 329)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(60, 40)
        Me.Button26.TabIndex = 16
        Me.Button26.Text = "3"
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button27.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button27.Location = New System.Drawing.Point(109, 329)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(60, 40)
        Me.Button27.TabIndex = 15
        Me.Button27.Text = "2"
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button28.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button28.Location = New System.Drawing.Point(25, 329)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(60, 40)
        Me.Button28.TabIndex = 5
        Me.Button28.Text = "1"
        Me.Button28.UseVisualStyleBackColor = True
        '
        'txtMETERAN
        '
        Me.txtMETERAN.Font = New System.Drawing.Font("Microsoft Sans Serif", 17.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMETERAN.Location = New System.Drawing.Point(71, 62)
        Me.txtMETERAN.Multiline = True
        Me.txtMETERAN.Name = "txtMETERAN"
        Me.txtMETERAN.Size = New System.Drawing.Size(142, 42)
        Me.txtMETERAN.TabIndex = 14
        Me.txtMETERAN.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'PictureBox12
        '
        Me.PictureBox12.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox12.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.meteran
        Me.PictureBox12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox12.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox12.Location = New System.Drawing.Point(25, 19)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(233, 285)
        Me.PictureBox12.TabIndex = 13
        Me.PictureBox12.TabStop = False
        '
        'tmrISIIN
        '
        Me.tmrISIIN.Interval = 10
        '
        'tmrISIOUT
        '
        Me.tmrISIOUT.Interval = 10
        '
        'tmrTONE
        '
        Me.tmrTONE.Interval = 10
        '
        'grpTOKEN
        '
        Me.grpTOKEN.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources._568f819ba81bb7a8348b45671
        Me.grpTOKEN.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.grpTOKEN.Controls.Add(Me.Button15)
        Me.grpTOKEN.Controls.Add(Me.Button14)
        Me.grpTOKEN.Controls.Add(Me.txtKODE)
        Me.grpTOKEN.Controls.Add(Me.Label3)
        Me.grpTOKEN.Controls.Add(Me.cmbSALDO)
        Me.grpTOKEN.Controls.Add(Me.lblnotoken)
        Me.grpTOKEN.Controls.Add(Me.lblWELCOME)
        Me.grpTOKEN.Controls.Add(Me.PictureBox10)
        Me.grpTOKEN.Controls.Add(Me.btnCLOSEINDO)
        Me.grpTOKEN.Controls.Add(Me.Label4)
        Me.grpTOKEN.Controls.Add(Me.lblTOKEN)
        Me.grpTOKEN.Controls.Add(Me.txtNOMOR)
        Me.grpTOKEN.Location = New System.Drawing.Point(0, 730)
        Me.grpTOKEN.Name = "grpTOKEN"
        Me.grpTOKEN.Size = New System.Drawing.Size(1108, 492)
        Me.grpTOKEN.TabIndex = 4
        Me.grpTOKEN.TabStop = False
        '
        'Button15
        '
        Me.Button15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button15.Location = New System.Drawing.Point(1056, 308)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(29, 26)
        Me.Button15.TabIndex = 23
        Me.Button15.Text = "ok"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button14.Location = New System.Drawing.Point(989, 398)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(96, 43)
        Me.Button14.TabIndex = 22
        Me.Button14.Text = "Save"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'txtKODE
        '
        Me.txtKODE.Enabled = False
        Me.txtKODE.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtKODE.Location = New System.Drawing.Point(624, 367)
        Me.txtKODE.Multiline = True
        Me.txtKODE.Name = "txtKODE"
        Me.txtKODE.Size = New System.Drawing.Size(461, 25)
        Me.txtKODE.TabIndex = 21
        Me.txtKODE.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label3.Location = New System.Drawing.Point(431, 376)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(132, 25)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "Kode Aktivasi"
        '
        'cmbSALDO
        '
        Me.cmbSALDO.FormattingEnabled = True
        Me.cmbSALDO.Items.AddRange(New Object() {"Rp 5000", "Rp 10.000", "Rp 20.000", "Rp 25.000", "Rp 50.000"})
        Me.cmbSALDO.Location = New System.Drawing.Point(624, 340)
        Me.cmbSALDO.Name = "cmbSALDO"
        Me.cmbSALDO.Size = New System.Drawing.Size(461, 21)
        Me.cmbSALDO.TabIndex = 19
        '
        'lblnotoken
        '
        Me.lblnotoken.AutoSize = True
        Me.lblnotoken.BackColor = System.Drawing.Color.Transparent
        Me.lblnotoken.Font = New System.Drawing.Font("Monotype Corsiva", 26.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblnotoken.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblnotoken.Location = New System.Drawing.Point(426, 169)
        Me.lblnotoken.Name = "lblnotoken"
        Me.lblnotoken.Size = New System.Drawing.Size(148, 43)
        Me.lblnotoken.TabIndex = 18
        Me.lblnotoken.Text = "Welcome!"
        '
        'lblWELCOME
        '
        Me.lblWELCOME.AutoSize = True
        Me.lblWELCOME.BackColor = System.Drawing.Color.Transparent
        Me.lblWELCOME.Font = New System.Drawing.Font("Monotype Corsiva", 26.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWELCOME.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblWELCOME.Location = New System.Drawing.Point(426, 121)
        Me.lblWELCOME.Name = "lblWELCOME"
        Me.lblWELCOME.Size = New System.Drawing.Size(148, 43)
        Me.lblWELCOME.TabIndex = 17
        Me.lblWELCOME.Text = "Welcome!"
        '
        'PictureBox10
        '
        Me.PictureBox10.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox10.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources._12135335_1128908357138252_2140847149_n1
        Me.PictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox10.Location = New System.Drawing.Point(5, 37)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(415, 454)
        Me.PictureBox10.TabIndex = 12
        Me.PictureBox10.TabStop = False
        Me.deskripsi.SetToolTip(Me.PictureBox10, "Mba-Mba Indomaret")
        '
        'btnCLOSEINDO
        '
        Me.btnCLOSEINDO.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCLOSEINDO.Location = New System.Drawing.Point(1014, 19)
        Me.btnCLOSEINDO.Name = "btnCLOSEINDO"
        Me.btnCLOSEINDO.Size = New System.Drawing.Size(88, 42)
        Me.btnCLOSEINDO.TabIndex = 16
        Me.btnCLOSEINDO.Text = "Close"
        Me.deskripsi.SetToolTip(Me.btnCLOSEINDO, "Keluar Indomaret")
        Me.btnCLOSEINDO.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(431, 344)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(58, 25)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "Saldo"
        '
        'lblTOKEN
        '
        Me.lblTOKEN.AutoSize = True
        Me.lblTOKEN.BackColor = System.Drawing.Color.Transparent
        Me.lblTOKEN.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTOKEN.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblTOKEN.Location = New System.Drawing.Point(431, 309)
        Me.lblTOKEN.Name = "lblTOKEN"
        Me.lblTOKEN.Size = New System.Drawing.Size(123, 25)
        Me.lblTOKEN.TabIndex = 12
        Me.lblTOKEN.Text = "Nomor Token"
        '
        'txtNOMOR
        '
        Me.txtNOMOR.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNOMOR.Location = New System.Drawing.Point(624, 309)
        Me.txtNOMOR.Multiline = True
        Me.txtNOMOR.Name = "txtNOMOR"
        Me.txtNOMOR.Size = New System.Drawing.Size(426, 25)
        Me.txtNOMOR.TabIndex = 0
        Me.txtNOMOR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'grpLUAR
        '
        Me.grpLUAR.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.luar
        Me.grpLUAR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.grpLUAR.Controls.Add(Me.PictureBox5)
        Me.grpLUAR.Controls.Add(Me.Label1)
        Me.grpLUAR.Controls.Add(Me.PictureBox3)
        Me.grpLUAR.Location = New System.Drawing.Point(1400, 30)
        Me.grpLUAR.Name = "grpLUAR"
        Me.grpLUAR.Size = New System.Drawing.Size(1108, 694)
        Me.grpLUAR.TabIndex = 3
        Me.grpLUAR.TabStop = False
        Me.grpLUAR.Text = "Luar Rumah"
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox5.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.house_icon_md
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox5.Location = New System.Drawing.Point(822, 194)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(239, 240)
        Me.PictureBox5.TabIndex = 6
        Me.PictureBox5.TabStop = False
        Me.deskripsi.SetToolTip(Me.PictureBox5, "Masuk Rumah")
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Location = New System.Drawing.Point(6, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(46, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "554,347"
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox3.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.Untitled_1
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox3.Location = New System.Drawing.Point(26, 164)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(309, 283)
        Me.PictureBox3.TabIndex = 3
        Me.PictureBox3.TabStop = False
        Me.deskripsi.SetToolTip(Me.PictureBox3, "Masuk Ke Indomaret")
        '
        'grpRUMAH
        '
        Me.grpRUMAH.BackColor = System.Drawing.SystemColors.Control
        Me.grpRUMAH.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.room_938750__340
        Me.grpRUMAH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.grpRUMAH.Controls.Add(Me.lblmonster)
        Me.grpRUMAH.Controls.Add(Me.pctM3)
        Me.grpRUMAH.Controls.Add(Me.pctM2)
        Me.grpRUMAH.Controls.Add(Me.pctM1)
        Me.grpRUMAH.Controls.Add(Me.btnSHOW)
        Me.grpRUMAH.Controls.Add(Me.grpPEMAKAIAN)
        Me.grpRUMAH.Controls.Add(Me.pctGSUARA)
        Me.grpRUMAH.Controls.Add(Me.pctTONE1)
        Me.grpRUMAH.Controls.Add(Me.Label7)
        Me.grpRUMAH.Controls.Add(Me.Label6)
        Me.grpRUMAH.Controls.Add(Me.lblISISALDO)
        Me.grpRUMAH.Controls.Add(Me.lblKODE)
        Me.grpRUMAH.Controls.Add(Me.pctARUSAC)
        Me.grpRUMAH.Controls.Add(Me.pctRADI)
        Me.grpRUMAH.Controls.Add(Me.PictureBox8)
        Me.grpRUMAH.Controls.Add(Me.pctTV)
        Me.grpRUMAH.Controls.Add(Me.pctmeja)
        Me.grpRUMAH.Controls.Add(Me.Label2)
        Me.grpRUMAH.Controls.Add(Me.PictureBox2)
        Me.grpRUMAH.Controls.Add(Me.PictureBox1)
        Me.grpRUMAH.Location = New System.Drawing.Point(0, 30)
        Me.grpRUMAH.Name = "grpRUMAH"
        Me.grpRUMAH.Size = New System.Drawing.Size(1108, 694)
        Me.grpRUMAH.TabIndex = 0
        Me.grpRUMAH.TabStop = False
        '
        'lblmonster
        '
        Me.lblmonster.AutoSize = True
        Me.lblmonster.BackColor = System.Drawing.Color.White
        Me.lblmonster.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmonster.Location = New System.Drawing.Point(438, 286)
        Me.lblmonster.Name = "lblmonster"
        Me.lblmonster.Size = New System.Drawing.Size(161, 24)
        Me.lblmonster.TabIndex = 44
        Me.lblmonster.Text = "Monster League"
        '
        'pctM3
        '
        Me.pctM3.BackColor = System.Drawing.Color.Black
        Me.pctM3.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.stock___dota_razor_by_mizkipz_d7w2kyy
        Me.pctM3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pctM3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pctM3.Location = New System.Drawing.Point(418, 274)
        Me.pctM3.Name = "pctM3"
        Me.pctM3.Size = New System.Drawing.Size(189, 144)
        Me.pctM3.TabIndex = 43
        Me.pctM3.TabStop = False
        '
        'pctM2
        '
        Me.pctM2.BackColor = System.Drawing.Color.Black
        Me.pctM2.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.creep
        Me.pctM2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pctM2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pctM2.Location = New System.Drawing.Point(445, 274)
        Me.pctM2.Name = "pctM2"
        Me.pctM2.Size = New System.Drawing.Size(192, 144)
        Me.pctM2.TabIndex = 42
        Me.pctM2.TabStop = False
        '
        'pctM1
        '
        Me.pctM1.BackColor = System.Drawing.Color.Black
        Me.pctM1.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.steamworkshop_webupload_previewfile_375511039_preview
        Me.pctM1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pctM1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pctM1.Location = New System.Drawing.Point(400, 274)
        Me.pctM1.Name = "pctM1"
        Me.pctM1.Size = New System.Drawing.Size(196, 144)
        Me.pctM1.TabIndex = 41
        Me.pctM1.TabStop = False
        '
        'btnSHOW
        '
        Me.btnSHOW.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSHOW.Location = New System.Drawing.Point(117, 88)
        Me.btnSHOW.Name = "btnSHOW"
        Me.btnSHOW.Size = New System.Drawing.Size(72, 43)
        Me.btnSHOW.TabIndex = 40
        Me.btnSHOW.Text = "Show"
        Me.deskripsi.SetToolTip(Me.btnSHOW, "Tampilan System Persentase")
        Me.btnSHOW.UseVisualStyleBackColor = True
        '
        'grpPEMAKAIAN
        '
        Me.grpPEMAKAIAN.BackColor = System.Drawing.Color.Transparent
        Me.grpPEMAKAIAN.Controls.Add(Me.lblGRAFIK)
        Me.grpPEMAKAIAN.Controls.Add(Me.LABELG3)
        Me.grpPEMAKAIAN.Controls.Add(Me.LABELG2)
        Me.grpPEMAKAIAN.Controls.Add(Me.LABELG1)
        Me.grpPEMAKAIAN.Controls.Add(Me.dotYELLOW)
        Me.grpPEMAKAIAN.Controls.Add(Me.dotRED)
        Me.grpPEMAKAIAN.Controls.Add(Me.dotGold)
        Me.grpPEMAKAIAN.Controls.Add(Me.Label11)
        Me.grpPEMAKAIAN.Controls.Add(Me.btngotv)
        Me.grpPEMAKAIAN.Controls.Add(Me.btngorad)
        Me.grpPEMAKAIAN.Controls.Add(Me.btngoac)
        Me.grpPEMAKAIAN.Controls.Add(Me.Label10)
        Me.grpPEMAKAIAN.Controls.Add(Me.lblpersentv)
        Me.grpPEMAKAIAN.Controls.Add(Me.lblANGKAUTV)
        Me.grpPEMAKAIAN.Controls.Add(Me.Label9)
        Me.grpPEMAKAIAN.Controls.Add(Me.Label8)
        Me.grpPEMAKAIAN.Controls.Add(Me.Label5)
        Me.grpPEMAKAIAN.Controls.Add(Me.btnSTAT)
        Me.grpPEMAKAIAN.Controls.Add(Me.lblpersenrad)
        Me.grpPEMAKAIAN.Controls.Add(Me.lblUAC)
        Me.grpPEMAKAIAN.Controls.Add(Me.lblpersenac)
        Me.grpPEMAKAIAN.Controls.Add(Me.lblURAD)
        Me.grpPEMAKAIAN.Controls.Add(Me.lblANGKAUAC)
        Me.grpPEMAKAIAN.Controls.Add(Me.lblANGKAURAD)
        Me.grpPEMAKAIAN.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpPEMAKAIAN.Location = New System.Drawing.Point(2, 182)
        Me.grpPEMAKAIAN.Name = "grpPEMAKAIAN"
        Me.grpPEMAKAIAN.Size = New System.Drawing.Size(292, 259)
        Me.grpPEMAKAIAN.TabIndex = 28
        Me.grpPEMAKAIAN.TabStop = False
        Me.grpPEMAKAIAN.Text = "Status Pemakaian"
        '
        'lblGRAFIK
        '
        Me.lblGRAFIK.AutoSize = True
        Me.lblGRAFIK.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGRAFIK.ForeColor = System.Drawing.Color.Black
        Me.lblGRAFIK.Location = New System.Drawing.Point(155, 230)
        Me.lblGRAFIK.Name = "lblGRAFIK"
        Me.lblGRAFIK.Size = New System.Drawing.Size(131, 16)
        Me.lblGRAFIK.TabIndex = 45
        Me.lblGRAFIK.Text = "Grafik Pemakaian"
        '
        'LABELG3
        '
        Me.LABELG3.AutoSize = True
        Me.LABELG3.BackColor = System.Drawing.Color.Transparent
        Me.LABELG3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LABELG3.Location = New System.Drawing.Point(248, 207)
        Me.LABELG3.Name = "LABELG3"
        Me.LABELG3.Size = New System.Drawing.Size(17, 18)
        Me.LABELG3.TabIndex = 52
        Me.LABELG3.Text = "0"
        '
        'LABELG2
        '
        Me.LABELG2.AutoSize = True
        Me.LABELG2.BackColor = System.Drawing.Color.Transparent
        Me.LABELG2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LABELG2.Location = New System.Drawing.Point(207, 207)
        Me.LABELG2.Name = "LABELG2"
        Me.LABELG2.Size = New System.Drawing.Size(17, 18)
        Me.LABELG2.TabIndex = 52
        Me.LABELG2.Text = "0"
        '
        'LABELG1
        '
        Me.LABELG1.AutoSize = True
        Me.LABELG1.BackColor = System.Drawing.Color.Transparent
        Me.LABELG1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LABELG1.Location = New System.Drawing.Point(166, 207)
        Me.LABELG1.Name = "LABELG1"
        Me.LABELG1.Size = New System.Drawing.Size(17, 18)
        Me.LABELG1.TabIndex = 52
        Me.LABELG1.Text = "0"
        '
        'dotYELLOW
        '
        Me.dotYELLOW.BackColor = System.Drawing.Color.MediumBlue
        Me.dotYELLOW.Location = New System.Drawing.Point(246, 192)
        Me.dotYELLOW.Name = "dotYELLOW"
        Me.dotYELLOW.Size = New System.Drawing.Size(35, 10)
        Me.dotYELLOW.TabIndex = 50
        Me.dotYELLOW.TabStop = False
        '
        'dotRED
        '
        Me.dotRED.BackColor = System.Drawing.Color.Red
        Me.dotRED.Location = New System.Drawing.Point(164, 192)
        Me.dotRED.Name = "dotRED"
        Me.dotRED.Size = New System.Drawing.Size(35, 10)
        Me.dotRED.TabIndex = 51
        Me.dotRED.TabStop = False
        '
        'dotGold
        '
        Me.dotGold.BackColor = System.Drawing.Color.OliveDrab
        Me.dotGold.Location = New System.Drawing.Point(205, 192)
        Me.dotGold.Name = "dotGold"
        Me.dotGold.Size = New System.Drawing.Size(35, 10)
        Me.dotGold.TabIndex = 49
        Me.dotGold.TabStop = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(20, 190)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(86, 18)
        Me.Label11.TabIndex = 48
        Me.Label11.Text = "EOE 0-2%"
        '
        'btngotv
        '
        Me.btngotv.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btngotv.Location = New System.Drawing.Point(68, 156)
        Me.btngotv.Name = "btngotv"
        Me.btngotv.Size = New System.Drawing.Size(28, 20)
        Me.btngotv.TabIndex = 47
        Me.btngotv.Text = "<>"
        Me.btngotv.UseVisualStyleBackColor = True
        '
        'btngorad
        '
        Me.btngorad.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btngorad.Location = New System.Drawing.Point(68, 100)
        Me.btngorad.Name = "btngorad"
        Me.btngorad.Size = New System.Drawing.Size(28, 20)
        Me.btngorad.TabIndex = 46
        Me.btngorad.Text = "<>"
        Me.btngorad.UseVisualStyleBackColor = True
        '
        'btngoac
        '
        Me.btngoac.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btngoac.Location = New System.Drawing.Point(68, 45)
        Me.btngoac.Name = "btngoac"
        Me.btngoac.Size = New System.Drawing.Size(28, 20)
        Me.btngoac.TabIndex = 41
        Me.btngoac.Text = "<>"
        Me.btngoac.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(51, 159)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(16, 13)
        Me.Label10.TabIndex = 45
        Me.Label10.Text = "%"
        '
        'lblpersentv
        '
        Me.lblpersentv.AutoSize = True
        Me.lblpersentv.BackColor = System.Drawing.Color.Transparent
        Me.lblpersentv.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpersentv.Location = New System.Drawing.Point(22, 155)
        Me.lblpersentv.Name = "lblpersentv"
        Me.lblpersentv.Size = New System.Drawing.Size(19, 20)
        Me.lblpersentv.TabIndex = 44
        Me.lblpersentv.Text = "0"
        '
        'lblANGKAUTV
        '
        Me.lblANGKAUTV.AutoSize = True
        Me.lblANGKAUTV.BackColor = System.Drawing.Color.Transparent
        Me.lblANGKAUTV.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblANGKAUTV.Location = New System.Drawing.Point(100, 157)
        Me.lblANGKAUTV.Name = "lblANGKAUTV"
        Me.lblANGKAUTV.Size = New System.Drawing.Size(19, 20)
        Me.lblANGKAUTV.TabIndex = 43
        Me.lblANGKAUTV.Text = "0"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.MediumBlue
        Me.Label9.Location = New System.Drawing.Point(16, 132)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(88, 20)
        Me.Label9.TabIndex = 42
        Me.Label9.Text = "TV Usage"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(50, 104)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(16, 13)
        Me.Label8.TabIndex = 41
        Me.Label8.Text = "%"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(50, 48)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(16, 13)
        Me.Label5.TabIndex = 40
        Me.Label5.Text = "%"
        '
        'btnSTAT
        '
        Me.btnSTAT.Location = New System.Drawing.Point(20, 211)
        Me.btnSTAT.Name = "btnSTAT"
        Me.btnSTAT.Size = New System.Drawing.Size(83, 34)
        Me.btnSTAT.TabIndex = 28
        Me.btnSTAT.Text = "Status"
        Me.deskripsi.SetToolTip(Me.btnSTAT, "Tampilkan Pemakaian")
        Me.btnSTAT.UseVisualStyleBackColor = True
        '
        'lblpersenrad
        '
        Me.lblpersenrad.AutoSize = True
        Me.lblpersenrad.BackColor = System.Drawing.Color.Transparent
        Me.lblpersenrad.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpersenrad.Location = New System.Drawing.Point(22, 100)
        Me.lblpersenrad.Name = "lblpersenrad"
        Me.lblpersenrad.Size = New System.Drawing.Size(19, 20)
        Me.lblpersenrad.TabIndex = 39
        Me.lblpersenrad.Text = "0"
        '
        'lblUAC
        '
        Me.lblUAC.AutoSize = True
        Me.lblUAC.BackColor = System.Drawing.Color.Transparent
        Me.lblUAC.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUAC.ForeColor = System.Drawing.Color.Red
        Me.lblUAC.Location = New System.Drawing.Point(16, 22)
        Me.lblUAC.Name = "lblUAC"
        Me.lblUAC.Size = New System.Drawing.Size(90, 20)
        Me.lblUAC.TabIndex = 34
        Me.lblUAC.Text = "AC Usage"
        '
        'lblpersenac
        '
        Me.lblpersenac.AutoSize = True
        Me.lblpersenac.BackColor = System.Drawing.Color.Transparent
        Me.lblpersenac.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpersenac.Location = New System.Drawing.Point(22, 44)
        Me.lblpersenac.Name = "lblpersenac"
        Me.lblpersenac.Size = New System.Drawing.Size(19, 20)
        Me.lblpersenac.TabIndex = 38
        Me.lblpersenac.Text = "0"
        '
        'lblURAD
        '
        Me.lblURAD.AutoSize = True
        Me.lblURAD.BackColor = System.Drawing.Color.Transparent
        Me.lblURAD.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblURAD.ForeColor = System.Drawing.Color.DarkGreen
        Me.lblURAD.Location = New System.Drawing.Point(16, 77)
        Me.lblURAD.Name = "lblURAD"
        Me.lblURAD.Size = New System.Drawing.Size(123, 20)
        Me.lblURAD.TabIndex = 35
        Me.lblURAD.Text = "RADIO Usage"
        '
        'lblANGKAUAC
        '
        Me.lblANGKAUAC.AutoSize = True
        Me.lblANGKAUAC.BackColor = System.Drawing.Color.Transparent
        Me.lblANGKAUAC.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblANGKAUAC.Location = New System.Drawing.Point(99, 45)
        Me.lblANGKAUAC.Name = "lblANGKAUAC"
        Me.lblANGKAUAC.Size = New System.Drawing.Size(19, 20)
        Me.lblANGKAUAC.TabIndex = 36
        Me.lblANGKAUAC.Text = "0"
        '
        'lblANGKAURAD
        '
        Me.lblANGKAURAD.AutoSize = True
        Me.lblANGKAURAD.BackColor = System.Drawing.Color.Transparent
        Me.lblANGKAURAD.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblANGKAURAD.Location = New System.Drawing.Point(99, 101)
        Me.lblANGKAURAD.Name = "lblANGKAURAD"
        Me.lblANGKAURAD.Size = New System.Drawing.Size(19, 20)
        Me.lblANGKAURAD.TabIndex = 37
        Me.lblANGKAURAD.Text = "0"
        '
        'pctGSUARA
        '
        Me.pctGSUARA.BackColor = System.Drawing.Color.Transparent
        Me.pctGSUARA.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.suara
        Me.pctGSUARA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pctGSUARA.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pctGSUARA.Location = New System.Drawing.Point(783, 375)
        Me.pctGSUARA.Name = "pctGSUARA"
        Me.pctGSUARA.Size = New System.Drawing.Size(144, 79)
        Me.pctGSUARA.TabIndex = 33
        Me.pctGSUARA.TabStop = False
        '
        'pctTONE1
        '
        Me.pctTONE1.BackColor = System.Drawing.Color.Transparent
        Me.pctTONE1.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.music_tone_md
        Me.pctTONE1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pctTONE1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pctTONE1.Location = New System.Drawing.Point(951, 450)
        Me.pctTONE1.Name = "pctTONE1"
        Me.pctTONE1.Size = New System.Drawing.Size(76, 58)
        Me.pctTONE1.TabIndex = 32
        Me.pctTONE1.TabStop = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(112, 18)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(76, 29)
        Me.Label7.TabIndex = 31
        Me.Label7.Text = "Saldo"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(112, 48)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 29)
        Me.Label6.TabIndex = 30
        Me.Label6.Text = "Rp"
        '
        'lblISISALDO
        '
        Me.lblISISALDO.AutoSize = True
        Me.lblISISALDO.BackColor = System.Drawing.Color.Transparent
        Me.lblISISALDO.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblISISALDO.Location = New System.Drawing.Point(155, 48)
        Me.lblISISALDO.Name = "lblISISALDO"
        Me.lblISISALDO.Size = New System.Drawing.Size(40, 29)
        Me.lblISISALDO.TabIndex = 29
        Me.lblISISALDO.Text = "isi"
        Me.deskripsi.SetToolTip(Me.lblISISALDO, "Current Saldo")
        '
        'lblKODE
        '
        Me.lblKODE.AutoSize = True
        Me.lblKODE.BackColor = System.Drawing.Color.Transparent
        Me.lblKODE.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKODE.Location = New System.Drawing.Point(20, 155)
        Me.lblKODE.Name = "lblKODE"
        Me.lblKODE.Size = New System.Drawing.Size(72, 24)
        Me.lblKODE.TabIndex = 28
        Me.lblKODE.Text = "Label5"
        Me.deskripsi.SetToolTip(Me.lblKODE, "Kode Aktivasi")
        '
        'pctARUSAC
        '
        Me.pctARUSAC.BackColor = System.Drawing.Color.Transparent
        Me.pctARUSAC.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.arus_ac
        Me.pctARUSAC.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pctARUSAC.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pctARUSAC.Location = New System.Drawing.Point(370, 140)
        Me.pctARUSAC.Name = "pctARUSAC"
        Me.pctARUSAC.Size = New System.Drawing.Size(314, 57)
        Me.pctARUSAC.TabIndex = 11
        Me.pctARUSAC.TabStop = False
        '
        'pctRADI
        '
        Me.pctRADI.BackColor = System.Drawing.Color.Transparent
        Me.pctRADI.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.Untitled_3
        Me.pctRADI.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pctRADI.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pctRADI.Location = New System.Drawing.Point(758, 450)
        Me.pctRADI.Name = "pctRADI"
        Me.pctRADI.Size = New System.Drawing.Size(187, 119)
        Me.pctRADI.TabIndex = 10
        Me.pctRADI.TabStop = False
        Me.deskripsi.SetToolTip(Me.pctRADI, "ON/OFF Radio")
        '
        'PictureBox8
        '
        Me.PictureBox8.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox8.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.ac
        Me.PictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox8.Location = New System.Drawing.Point(291, -11)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(453, 158)
        Me.PictureBox8.TabIndex = 9
        Me.PictureBox8.TabStop = False
        Me.deskripsi.SetToolTip(Me.PictureBox8, "ON/OFF AC")
        '
        'pctTV
        '
        Me.pctTV.BackColor = System.Drawing.Color.Black
        Me.pctTV.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pctTV.Location = New System.Drawing.Point(400, 274)
        Me.pctTV.Name = "pctTV"
        Me.pctTV.Size = New System.Drawing.Size(237, 144)
        Me.pctTV.TabIndex = 8
        Me.pctTV.TabStop = False
        Me.deskripsi.SetToolTip(Me.pctTV, "ON/OFF TV")
        '
        'pctmeja
        '
        Me.pctmeja.BackColor = System.Drawing.Color.Transparent
        Me.pctmeja.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.tv_meja
        Me.pctmeja.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pctmeja.Location = New System.Drawing.Point(310, 262)
        Me.pctmeja.Name = "pctmeja"
        Me.pctmeja.Size = New System.Drawing.Size(400, 315)
        Me.pctmeja.TabIndex = 7
        Me.pctmeja.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(19, 134)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 24)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "554347"
        Me.deskripsi.SetToolTip(Me.Label2, "Id Meteran")
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.next_icon_2970
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox2.Location = New System.Drawing.Point(977, 16)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(127, 115)
        Me.PictureBox2.TabIndex = 2
        Me.PictureBox2.TabStop = False
        Me.deskripsi.SetToolTip(Me.PictureBox2, "GO OUT")
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.meteran
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox1.Location = New System.Drawing.Point(6, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(99, 119)
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        Me.deskripsi.SetToolTip(Me.PictureBox1, "Pengisian Saldo")
        '
        'deskripsi
        '
        Me.deskripsi.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info
        Me.deskripsi.ToolTipTitle = "Information"
        '
        'led2
        '
        Me.led2.Interval = 10
        '
        'led3
        '
        Me.led3.Interval = 10
        '
        'led1
        '
        Me.led1.Interval = 10
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1108, 24)
        Me.MenuStrip1.TabIndex = 28
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CreatorToolStripMenuItem, Me.SourceCodeToolStripMenuItem})
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'CreatorToolStripMenuItem
        '
        Me.CreatorToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ProfileToolStripMenuItem})
        Me.CreatorToolStripMenuItem.Name = "CreatorToolStripMenuItem"
        Me.CreatorToolStripMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.CreatorToolStripMenuItem.Text = "Creator"
        '
        'ProfileToolStripMenuItem
        '
        Me.ProfileToolStripMenuItem.Name = "ProfileToolStripMenuItem"
        Me.ProfileToolStripMenuItem.Size = New System.Drawing.Size(108, 22)
        Me.ProfileToolStripMenuItem.Text = "Profile"
        '
        'SourceCodeToolStripMenuItem
        '
        Me.SourceCodeToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TimerToolStripMenuItem, Me.ButtonToolStripMenuItem, Me.PictureToolStripMenuItem})
        Me.SourceCodeToolStripMenuItem.Name = "SourceCodeToolStripMenuItem"
        Me.SourceCodeToolStripMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.SourceCodeToolStripMenuItem.Text = "Source Code"
        '
        'TimerToolStripMenuItem
        '
        Me.TimerToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TToolStripMenuItem, Me.AnimasiRadioToolStripMenuItem, Me.AnimasiTVToolStripMenuItem, Me.AnimasiKeluarRumahToolStripMenuItem, Me.AnimasiMasukAlfamartToolStripMenuItem, Me.AnimasiTextSelamatDatangToolStripMenuItem, Me.AnimasiPengisianTokenToolStripMenuItem, Me.AnimasiGrafikPemakaianToolStripMenuItem})
        Me.TimerToolStripMenuItem.Name = "TimerToolStripMenuItem"
        Me.TimerToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.TimerToolStripMenuItem.Text = "Animasi"
        '
        'TToolStripMenuItem
        '
        Me.TToolStripMenuItem.Name = "TToolStripMenuItem"
        Me.TToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.TToolStripMenuItem.Text = "Animasi AC"
        '
        'AnimasiRadioToolStripMenuItem
        '
        Me.AnimasiRadioToolStripMenuItem.Name = "AnimasiRadioToolStripMenuItem"
        Me.AnimasiRadioToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.AnimasiRadioToolStripMenuItem.Text = "Animasi Radio"
        '
        'AnimasiTVToolStripMenuItem
        '
        Me.AnimasiTVToolStripMenuItem.Name = "AnimasiTVToolStripMenuItem"
        Me.AnimasiTVToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.AnimasiTVToolStripMenuItem.Text = "Animasi TV"
        '
        'AnimasiKeluarRumahToolStripMenuItem
        '
        Me.AnimasiKeluarRumahToolStripMenuItem.Name = "AnimasiKeluarRumahToolStripMenuItem"
        Me.AnimasiKeluarRumahToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.AnimasiKeluarRumahToolStripMenuItem.Text = "Animasi Keluar rumah"
        '
        'AnimasiMasukAlfamartToolStripMenuItem
        '
        Me.AnimasiMasukAlfamartToolStripMenuItem.Name = "AnimasiMasukAlfamartToolStripMenuItem"
        Me.AnimasiMasukAlfamartToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.AnimasiMasukAlfamartToolStripMenuItem.Text = "Animasi Masuk Alfamart"
        '
        'AnimasiTextSelamatDatangToolStripMenuItem
        '
        Me.AnimasiTextSelamatDatangToolStripMenuItem.Name = "AnimasiTextSelamatDatangToolStripMenuItem"
        Me.AnimasiTextSelamatDatangToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.AnimasiTextSelamatDatangToolStripMenuItem.Text = "Animasi Text Alfamart"
        '
        'AnimasiPengisianTokenToolStripMenuItem
        '
        Me.AnimasiPengisianTokenToolStripMenuItem.Name = "AnimasiPengisianTokenToolStripMenuItem"
        Me.AnimasiPengisianTokenToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.AnimasiPengisianTokenToolStripMenuItem.Text = "Animasi Pengisian Token"
        '
        'AnimasiGrafikPemakaianToolStripMenuItem
        '
        Me.AnimasiGrafikPemakaianToolStripMenuItem.Name = "AnimasiGrafikPemakaianToolStripMenuItem"
        Me.AnimasiGrafikPemakaianToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.AnimasiGrafikPemakaianToolStripMenuItem.Text = "Animasi Grafik Pemakaian"
        '
        'ButtonToolStripMenuItem
        '
        Me.ButtonToolStripMenuItem.Name = "ButtonToolStripMenuItem"
        Me.ButtonToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.ButtonToolStripMenuItem.Text = "Button"
        '
        'PictureToolStripMenuItem
        '
        Me.PictureToolStripMenuItem.Name = "PictureToolStripMenuItem"
        Me.PictureToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.PictureToolStripMenuItem.Text = "Picture"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ManualBookToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'ManualBookToolStripMenuItem
        '
        Me.ManualBookToolStripMenuItem.Name = "ManualBookToolStripMenuItem"
        Me.ManualBookToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.ManualBookToolStripMenuItem.Text = "Manual Book"
        '
        'tmrGRAFIK
        '
        Me.tmrGRAFIK.Interval = 200
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1108, 726)
        Me.Controls.Add(Me.grpISI)
        Me.Controls.Add(Me.grpTOKEN)
        Me.Controls.Add(Me.grpLUAR)
        Me.Controls.Add(Me.grpRUMAH)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.grpISI.ResumeLayout(False)
        Me.grpISI.PerformLayout()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpTOKEN.ResumeLayout(False)
        Me.grpTOKEN.PerformLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpLUAR.ResumeLayout(False)
        Me.grpLUAR.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpRUMAH.ResumeLayout(False)
        Me.grpRUMAH.PerformLayout()
        CType(Me.pctM3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctM2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctM1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpPEMAKAIAN.ResumeLayout(False)
        Me.grpPEMAKAIAN.PerformLayout()
        CType(Me.dotYELLOW, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dotRED, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dotGold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctGSUARA, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctTONE1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctARUSAC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctRADI, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctTV, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctmeja, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grpRUMAH As GroupBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents grpLUAR As GroupBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents tmrLUAR As Timer
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents tmrRUMAH As Timer
    Friend WithEvents pctmeja As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents pctTV As PictureBox
    Friend WithEvents pctRADI As PictureBox
    Friend WithEvents pctARUSAC As PictureBox
    Friend WithEvents tmrAC As Timer
    Friend WithEvents tmrTV As Timer
    Friend WithEvents grpTOKEN As GroupBox
    Friend WithEvents Label4 As Label
    Friend WithEvents lblTOKEN As Label
    Friend WithEvents txtNOMOR As TextBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents btnCLOSEINDO As Button
    Friend WithEvents tmrMASUKINDO As Timer
    Friend WithEvents lblWELCOME As Label
    Friend WithEvents tmrKELUARINDO As Timer
    Friend WithEvents tmrmbakindo As Timer
    Friend WithEvents lblnotoken As Label
    Friend WithEvents txtKODE As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents cmbSALDO As ComboBox
    Friend WithEvents Button14 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents grpISI As GroupBox
    Friend WithEvents Button16 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents Button19 As Button
    Friend WithEvents Button20 As Button
    Friend WithEvents Button21 As Button
    Friend WithEvents Button22 As Button
    Friend WithEvents Button23 As Button
    Friend WithEvents Button24 As Button
    Friend WithEvents Button25 As Button
    Friend WithEvents Button26 As Button
    Friend WithEvents Button27 As Button
    Friend WithEvents Button28 As Button
    Friend WithEvents txtMETERAN As TextBox
    Friend WithEvents PictureBox12 As PictureBox
    Friend WithEvents tmrISIIN As Timer
    Friend WithEvents tmrISIOUT As Timer
    Friend WithEvents lblKODE As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents lblISISALDO As Label
    Friend WithEvents pctTONE1 As PictureBox
    Friend WithEvents tmrTONE As Timer
    Friend WithEvents pctGSUARA As PictureBox
    Friend WithEvents lblURAD As Label
    Friend WithEvents lblUAC As Label
    Friend WithEvents lblANGKAURAD As Label
    Friend WithEvents lblANGKAUAC As Label
    Friend WithEvents btnSTAT As Button
    Friend WithEvents lblpersenrad As Label
    Friend WithEvents lblpersenac As Label
    Friend WithEvents btnSHOW As Button
    Friend WithEvents grpPEMAKAIAN As GroupBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents lblpersentv As Label
    Friend WithEvents lblANGKAUTV As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents btngotv As Button
    Friend WithEvents btngorad As Button
    Friend WithEvents btngoac As Button
    Friend WithEvents pctM1 As PictureBox
    Friend WithEvents pctM3 As PictureBox
    Friend WithEvents pctM2 As PictureBox
    Friend WithEvents lblmonster As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents deskripsi As ToolTip
    Friend WithEvents dotYELLOW As System.Windows.Forms.PictureBox
    Friend WithEvents dotRED As System.Windows.Forms.PictureBox
    Friend WithEvents dotGold As System.Windows.Forms.PictureBox
    Friend WithEvents led2 As System.Windows.Forms.Timer
    Friend WithEvents led3 As System.Windows.Forms.Timer
    Friend WithEvents led1 As System.Windows.Forms.Timer
    Friend WithEvents LABELG3 As System.Windows.Forms.Label
    Friend WithEvents LABELG2 As System.Windows.Forms.Label
    Friend WithEvents LABELG1 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreatorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SourceCodeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ManualBookToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblGRAFIK As System.Windows.Forms.Label
    Friend WithEvents TimerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AnimasiRadioToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AnimasiTVToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AnimasiKeluarRumahToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AnimasiMasukAlfamartToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AnimasiTextSelamatDatangToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AnimasiPengisianTokenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AnimasiGrafikPemakaianToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ButtonToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProfileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tmrGRAFIK As System.Windows.Forms.Timer
End Class
